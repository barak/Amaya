#ifndef TEMPLATE_DECLARATIONS
#define TEMPLATE_DECLARATIONS

#ifdef TEMPLATES
	//List of loaded templates and libraries
  THOT_EXPORT HashMap Templates_Map;
#endif
#endif //TEMPLATE_DECLARATIONS
