/*
 *
 *  (c) COPYRIGHT INRIA, 1996.
 *  Please first read the full copyright statement in file COPYRIGHT.
 *
 */
 
/* res.var */
	
THOT_EXPORT char BasicStamps [7];

THOT_EXPORT char NatureStamp;
THOT_EXPORT char UnitStamp;
THOT_EXPORT char AOD;
THOT_EXPORT char AED;
THOT_EXPORT char LOD;
THOT_EXPORT char LED;
THOT_EXPORT char COD;
THOT_EXPORT char CED;
THOT_EXPORT char ROD;
THOT_EXPORT char RED;
THOT_EXPORT char XOD;
THOT_EXPORT char XED;
THOT_EXPORT char SEP;
THOT_EXPORT char REMPTY;

THOT_EXPORT int COMP, THOTMSG, RESDYNMSG;


THOT_EXPORT TyResdynCt ResdynCt;

StrListeMem *pListeMem;

