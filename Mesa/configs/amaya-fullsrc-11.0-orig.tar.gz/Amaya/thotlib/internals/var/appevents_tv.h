/*
 *
 *  (c) COPYRIGHT INRIA, 1996.
 *  Please first read the full copyright statement in file COPYRIGHT.
 *
 */
 

#ifndef THOT_APPEVENTS_VAR
#define THOT_APPEVENTS_VAR

THOT_EXPORT PtrEventsSet  SchemasEvents;
THOT_EXPORT PtrEventsSet  EditorEvents;
THOT_EXPORT PtrAction     ActionList;

#endif /* THOT_APPEVENTS_VAR */
