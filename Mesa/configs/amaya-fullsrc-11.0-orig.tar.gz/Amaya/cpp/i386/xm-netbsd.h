/* Configuration for GCC for Intel i386 running NetBSD as host.  */

#include <i386/xm-i386.h>
#include <xm-netbsd.h>
